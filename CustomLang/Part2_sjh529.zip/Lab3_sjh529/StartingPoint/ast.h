// =============================================================================
//   ast.h — AST for TIPS Subset (matches PDF diagrams)
// =============================================================================
// MSU CSE 4714/6714 Capstone Project (Fall 2025)
// Author: Derek Willis
//
//   Part 1 : PROGRAM, BLOCK, WRITE
//   Part 2 : VAR/READ/ASSIGN + symtab + Compound Statement + BLOCK (fr this time)
//   Part 3 : expression/simple/term/factor + relations/logic/arithmetic
//   Part 4 : IF/WHILE, custom op/keyword, skins
// =============================================================================
#pragma once
#include <memory>
#include <string>
#include <iostream>
#include <vector>
#include <map>
#include <variant>
#include <cassert>
using namespace std;

// -----------------------------------------------------------------------------
// Pretty printer
// -----------------------------------------------------------------------------
inline void ast_line(ostream& os, string prefix, bool last, string label) {
  os << prefix << (last ? "└── " : "├── ") << label << "\n";
}

// Symbol Table
inline map<string, variant<int, double>> symbolTable;

// Forward Declarations
struct Write;
struct Block;
struct Statement;
struct assignStmt;
struct readStmt;
struct writeStmt;
struct compoundStmt;
struct Program;

// TODO: Define and Implement structures to hold each data node
// TODO: Overload << for Program

struct Statement        // Base clase for all statements
{
  // Member Variables
  // Member Functions
  virtual void print_tree(ostream& out, string prefix) = 0;
  virtual void interpret(ostream&) = 0;
};
struct assignStmt:Statement    // Update an existing variable's value
{
  // Member Variables
  string id;      // key of the symbolTable
  Token type;     // value's type
  string value;   // value of the symbolTable

  // Member Functions
  void print_tree(ostream& out, string prefix)
  {
    ast_line(out, prefix, true, "AssignStmt: " + id + " := " + value);    // Print "AssignStmt id := value" using ast_line for beauty
  }
  void interpret(ostream& out)  {
    (void) out;   // Ignores warnings from out not being used
    auto left = symbolTable[id];  

    // INTLIT Check
    if(type == INTLIT)    
    {
      int v = stoi(value);  
      if(holds_alternative<int>(left)) left = v;    
      else                              left = static_cast<double>(v);  
    }
    // FLOATLIT Check
    else if (type == FLOATLIT)  
    {
      double v = stod(value); 
      if(holds_alternative<int> (left)) left = static_cast<int>(v); 
      else                                left = v;                 
    }
    // IDENT Check
    else    
    {
      auto right = symbolTable[value];   
      if(holds_alternative<int>(left))    
      {
        left = holds_alternative<int>(right) ? get<int> (right) 
                                             : static_cast<int>(get<double>(right));  
      }
      else
      {
        left = holds_alternative<int> (right) ? static_cast<double> (get<int>(right)) 
                                              : get<double>(right);   
      }
    }
    symbolTable[id] = left; // Put left into the id of the table
  }
};
struct readStmt:Statement    // Read input into a variable
{
  // Member Variables
  string target;

  // Member Functions
  void print_tree(ostream& os, string prefix)
  {
    ast_line(os, prefix, true, "ReadStmt: " + target);
  }
  void interpret(ostream& out)
  {
    auto it = symbolTable.find(target);
    // if (it == symbolTable.end())
    //   throw runtime_error("readStmt: undeclared variable");
    
    visit([&](auto& value) { cin >> value; }, it->second);
  }
};

struct writeStmt:Statement   // Outputs value or a string
{
  // Member Variables
  string content;
  Token type;

  // Member Functions
  void print_tree(ostream& os, string prefix)
  {
      if (type == IDENT)
      {
        ast_line(os, prefix, true, "writeStmt (IDENT): " + content);
      }
      else
      {
        ast_line(os, prefix, true, "writeStmt (STRING): " + content);
      }
  }
  void interpret(ostream& out)
  {
    auto it = symbolTable.find(content);
    // if (it == symbolTable.end())
    //   throw runtime_error("Interpret: undeclared variable");

    if (type == IDENT)
    {
      visit([&out](auto&& value) { out << value << endl; }, it->second);
    }
    else
    {
       out << content << endl; 
    }
  }
};

struct compoundStmt:Statement    // A sequence of statements
{
  // Member Variables
  vector<unique_ptr<Statement>> stmts;

  // Member Functions
  void print_tree(ostream& os, string prefix)  // Displays a "pretty" list of children
  {
    for(auto& s : stmts) s->print_tree(os, "   "+prefix);
  }
  void interpret(ostream& out)   // For s in stmts: s->interpret(out)
  {
    for(auto& s : stmts) {s->interpret(out);}
  }
};
struct Block 
{
  // Member Variables
  unique_ptr<compoundStmt> compound;
  void print_tree(ostream& out) 
  {
    ast_line(out, "", true, "Block");
    if(!symbolTable.empty())
    {
      ast_line(out, "  ", false, "Symbol Table:");
      for(auto& [id, value] : symbolTable)
      {
        if(holds_alternative<int>(value))   // Check for int
          ast_line(out, "   ", true, id + " := " + to_string(get<int>(value)));
        else
          ast_line(out, "   ", true, id + " := " + to_string(get<double>(value)));
      }
    }
    if(compound) compound->print_tree(out, "  "); // Prints the tree for compound
  }
  void interpret(ostream& out) { if (compound) compound->interpret(out); }
};

struct Program 
{
  string name; 
  unique_ptr<Block> block;
  void print_tree(ostream& os)
  {
    cout << "Program\n";
    ast_line(os, "", false, "name: " + name);
    if (block) block->print_tree(os);
    else 
    { 
      ast_line(os, "", true, "Block"); 
      ast_line(os, "    ", true, "(empty)");
    }
  }
  void interpret(ostream& out) { if (block) block->interpret(out); }

  friend ostream& operator<<(ostream& os, unique_ptr<Program>& p)
  {
    if(p) p->print_tree(os);
    return os;
  }
};